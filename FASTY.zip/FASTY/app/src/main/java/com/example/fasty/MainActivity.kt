package com.example.fasty

import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import android.os.Bundle
import android.widget.Button
import com.example.fasty.R
import com.google.firebase.FirebaseApp
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {
    private var databaseReference: DatabaseReference? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val firebaseDatabase = FirebaseDatabase.getInstance()
        databaseReference = firebaseDatabase.getReference()


        val btnForward = findViewById<Button>(R.id.buttonForward)
        val btnBackward = findViewById<Button>(R.id.buttonBackward)
        val btnLeft = findViewById<Button>(R.id.buttonLeft)
        val btnRight = findViewById<Button>(R.id.buttonRight)
        val stp = findViewById<Button>(R.id.buttonStop)
        btnForward.setOnClickListener {
            sendCommand("3") // Send command to move forward
        }
        stp.setOnClickListener {
            sendCommand("0") // Send command to stop
        }
        btnBackward.setOnClickListener {
            sendCommand("2") // Send command to move backward
        }
        btnLeft.setOnClickListener {
            sendCommand("-1") // Send command to move left
        }
        btnRight.setOnClickListener {
            sendCommand("1") // Send command to move right
        }
    }

    private fun sendCommand(command: String) {
        databaseReference!!.child("command").setValue(command)
    }
}