package com.example.fasty

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ViewTreeObserver
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class Login : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    // [END declare_auth]


    lateinit var email: EditText
    lateinit var password: EditText
    lateinit var main: Intent

    lateinit var loginn: Button
    lateinit var regis: TextView


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        email= findViewById<EditText>(R.id.roomname)
        password= findViewById<EditText>(R.id.codetype)
        main = Intent(this, MainActivity::class.java)
        loginn= findViewById<Button>(R.id.loginbtn)
        // [START initialize_auth]
        // Initialize Firebase Auth
        auth = Firebase.auth
        // [END initialize_auth]
        loginn.setOnClickListener {
            if(password.text.isEmpty()){
                password.setError("Enter your password")
            }
            if(email.text.isEmpty()){
                email.setError("Enter your email")
            }
            if(!email.text.isEmpty()&&!password.text.isEmpty()){
                startSignIn()

            }
        }

    }


    fun startSignIn() {
        auth.signInWithEmailAndPassword(email.text.toString(), password.text.toString())
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    Toast.makeText(this,"Let's Start", Toast.LENGTH_SHORT).show()
                    updateUI(user)
                    startActivity(main)
                } else {
                    Toast.makeText(this,"invalid email or password", Toast.LENGTH_SHORT).show()
                    updateUI(null)
                }

            }

    }


    private fun updateUI(user: FirebaseUser?) {

    }

    companion object {
        private const val TAG = "CustomAuthActivity"
    }

}
